import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Route =
  | "welcome"
  | "signup"
  | "login"
  | "onboarding"
  | "home"
  | "practice"
  | "course"
  | "paper"
  | "quiz-setup"
  | "quiz"
  | "results"
  | "quiz-history"
  | "battle"
  | "challenge"
  | "battle-active"
  | "battle-result"
  | "leaderboard"
  | "profile"
  | "contribute"
  | "suggest"
  | "notifications"
  | "states"
  | "components"
  | "admin";

type IconName =
  | "home"
  | "book"
  | "swords"
  | "trophy"
  | "user"
  | "bell"
  | "search"
  | "filter"
  | "arrow"
  | "back"
  | "check"
  | "clock"
  | "fire"
  | "chart"
  | "bookmark"
  | "download"
  | "file"
  | "play"
  | "settings"
  | "share"
  | "plus"
  | "upload"
  | "close"
  | "menu"
  | "target"
  | "spark"
  | "grid"
  | "users"
  | "shield"
  | "logout"
  | "chevron"
  | "more";

const iconPaths: Record<IconName, ReactNode> = {
  home: (
    <>
      <path d="m3 11 9-8 9 8" />
      <path d="M5 10v10h14V10M9 20v-6h6v6" />
    </>
  ),
  book: (
    <>
      <path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H11v17H6.5A2.5 2.5 0 0 0 4 21.5Z" />
      <path d="M20 4.5A2.5 2.5 0 0 0 17.5 2H13v17h4.5a2.5 2.5 0 0 1 2.5 2.5Z" />
    </>
  ),
  swords: (
    <>
      <path d="m14.5 6.5 3-3 3 3-3 3M13 8l6 6M5 4l15 15M5 4l-1 5 5-1M9.5 14.5l-6 6M3.5 17.5l3 3" />
    </>
  ),
  trophy: (
    <>
      <path d="M8 4h8v5a4 4 0 0 1-8 0Z" />
      <path d="M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4M12 13v4M8 21h8M9 17h6v4" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </>
  ),
  bell: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </>
  ),
  filter: <path d="M4 5h16M7 12h10M10 19h4" />,
  arrow: (
    <>
      <path d="M5 12h14M14 7l5 5-5 5" />
    </>
  ),
  back: (
    <>
      <path d="M19 12H5M10 7l-5 5 5 5" />
    </>
  ),
  check: <path d="m5 12 4 4L19 6" />,
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3 2" />
    </>
  ),
  fire: (
    <path d="M12 22c4 0 7-3 7-7 0-5-4-9-7-13 0 5-7 7-7 13 0 4 3 7 7 7Zm0-3c-2 0-3-1-3-3s2-3 3-5c0 2 3 3 3 5s-1 3-3 3Z" />
  ),
  chart: (
    <>
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  bookmark: <path d="M6 3h12v18l-6-4-6 4Z" />,
  download: (
    <>
      <path d="M12 3v12M7 10l5 5 5-5M4 21h16" />
    </>
  ),
  file: (
    <>
      <path d="M6 2h8l4 4v16H6Z" />
      <path d="M14 2v5h5M9 12h6M9 16h6" />
    </>
  ),
  play: <path d="m8 5 11 7-11 7Z" />,
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1a7 7 0 0 0-1.8-1L14.4 3h-4l-.4 3.1a7 7 0 0 0-1.8 1l-2.4-1-2 3.4 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.4 2.4-1a7 7 0 0 0 1.8 1l.4 3.1h4l.4-3.1a7 7 0 0 0 1.8-1l2.4 1 2-3.4-2-1.5a7 7 0 0 0 .1-1Z" />
    </>
  ),
  share: (
    <>
      <circle cx="18" cy="5" r="2" />
      <circle cx="6" cy="12" r="2" />
      <circle cx="18" cy="19" r="2" />
      <path d="m8 11 8-5M8 13l8 5" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  upload: (
    <>
      <path d="M12 16V4M7 9l5-5 5 5M4 20h16" />
    </>
  ),
  close: <path d="m5 5 14 14M19 5 5 19" />,
  menu: <path d="M4 6h16M4 12h16M4 18h16" />,
  target: (
    <>
      <circle cx="12" cy="12" r="9" />
      <circle cx="12" cy="12" r="4" />
      <path d="m15 9 6-6" />
    </>
  ),
  spark: <path d="m12 2 2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2Z" />,
  grid: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1" />
      <rect x="14" y="3" width="7" height="7" rx="1" />
      <rect x="3" y="14" width="7" height="7" rx="1" />
      <rect x="14" y="14" width="7" height="7" rx="1" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3" />
      <path d="M3 20a6 6 0 0 1 12 0M16 5a3 3 0 0 1 0 6M17 14a5 5 0 0 1 4 5" />
    </>
  ),
  shield: <path d="M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z" />,
  logout: (
    <>
      <path d="M10 4H4v16h6M14 8l4 4-4 4M8 12h10" />
    </>
  ),
  chevron: <path d="m9 5 7 7-7 7" />,
  more: (
    <>
      <circle cx="5" cy="12" r="1" />
      <circle cx="12" cy="12" r="1" />
      <circle cx="19" cy="12" r="1" />
    </>
  ),
};

function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  return (
    <svg
      className="icon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {iconPaths[name]}
    </svg>
  );
}

const routeFromHash = (): Route => {
  const value = window.location.hash.replace("#/", "") as Route;
  const routes: Route[] = [
    "welcome",
    "signup",
    "login",
    "onboarding",
    "home",
    "practice",
    "course",
    "paper",
    "quiz-setup",
    "quiz",
    "results",
    "quiz-history",
    "battle",
    "challenge",
    "battle-active",
    "battle-result",
    "leaderboard",
    "profile",
    "contribute",
    "suggest",
    "notifications",
    "states",
    "components",
    "admin",
  ];
  return routes.includes(value) ? value : "home";
};
const go = (route: Route) => {
  window.location.hash = `#/${route}`;
};

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <button className="logo" onClick={() => go("home")} aria-label="Rimbly home">
      <span className="logo-mark">R</span>
      {!compact && <span>Rimbly</span>}
    </button>
  );
}

function Button({
  children,
  variant = "primary",
  icon,
  onClick,
  type = "button",
  full = false,
  disabled = false,
}: {
  children: ReactNode;
  variant?: "primary" | "secondary" | "ghost" | "danger" | "amber";
  icon?: IconName;
  onClick?: () => void;
  type?: "button" | "submit";
  full?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      className={`btn btn-${variant}${full ? " btn-full" : ""}`}
      onClick={onClick}
      type={type}
      disabled={disabled}
    >
      {children}
      {icon && <Icon name={icon} size={18} />}
    </button>
  );
}

function Badge({
  children,
  tone = "neutral",
  live = false,
}: {
  children: ReactNode;
  tone?: "neutral" | "purple" | "amber" | "green" | "red";
  live?: boolean;
}) {
  return (
    <span className={`badge badge-${tone}`}>
      {live && <span className="live-dot" />}
      {children}
    </span>
  );
}

function Avatar({
  initials,
  size = "md",
  rank,
}: {
  initials: string;
  size?: "sm" | "md" | "lg";
  rank?: number;
}) {
  return (
    <span className={`avatar avatar-${size}`}>
      {initials}
      {rank && <b>{rank}</b>}
    </span>
  );
}

function Progress({ value, label }: { value: number; label?: string }) {
  return (
    <div className="progress-wrap">
      {label && (
        <div className="progress-label">
          <span>{label}</span>
          <b>{value}%</b>
        </div>
      )}
      <div className="progress">
        <span style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

const navItems: { route: Route; label: string; icon: IconName }[] = [
  { route: "home", label: "Home", icon: "home" },
  { route: "practice", label: "Practice", icon: "book" },
  { route: "battle", label: "Battle", icon: "swords" },
  { route: "leaderboard", label: "Leaders", icon: "trophy" },
  { route: "profile", label: "Profile", icon: "user" },
];

function TopBar({
  title,
  back,
  action = true,
}: {
  title?: string;
  back?: Route;
  action?: boolean;
}) {
  return (
    <header className="app-topbar">
      <div className="topbar-inner">
        {back ? (
          <button className="icon-btn" onClick={() => go(back)} aria-label="Go back">
            <Icon name="back" />
          </button>
        ) : (
          <Logo />
        )}
        <strong className="mobile-page-title">{title}</strong>
        {action ? (
          <button
            className="icon-btn notification-btn"
            onClick={() => go("notifications")}
            aria-label="Notifications"
          >
            <Icon name="bell" />
            <i />
          </button>
        ) : (
          <span className="topbar-spacer" />
        )}
      </div>
    </header>
  );
}

function BottomNav({ route }: { route: Route }) {
  return (
    <nav className="bottom-nav" aria-label="Main navigation">
      {navItems.map((item) => (
        <button
          key={item.route}
          className={
            route === item.route ||
            (item.route === "practice" &&
              ["course", "paper", "quiz-setup", "quiz", "results", "quiz-history"].includes(
                route,
              )) ||
            (item.route === "battle" &&
              ["challenge", "battle-active", "battle-result"].includes(route))
              ? "active"
              : ""
          }
          onClick={() => go(item.route)}
        >
          <Icon name={item.icon} />
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

function DesktopSidebar({ route }: { route: Route }) {
  return (
    <aside className="desktop-sidebar">
      <Logo />
      <div className="student-context">
        <Avatar initials="DA" />
        <span>
          <b>Dami Adebayo</b>
          <small>UNILAG · 300L</small>
        </span>
      </div>
      <nav>
        {navItems.map((item) => (
          <button
            key={item.route}
            className={route === item.route ? "active" : ""}
            onClick={() => go(item.route)}
          >
            <Icon name={item.icon} />
            {item.label}
          </button>
        ))}
      </nav>
      <div className="sidebar-bottom">
        <button onClick={() => go("contribute")}>
          <Icon name="upload" />
          Contribute
        </button>
        <button onClick={() => go("components")}>
          <Icon name="grid" />
          UI Library
        </button>
      </div>
    </aside>
  );
}

function AppShell({
  route,
  title,
  children,
  back,
  hideNav = false,
}: {
  route: Route;
  title?: string;
  children: ReactNode;
  back?: Route;
  hideNav?: boolean;
}) {
  return (
    <div className="app-shell">
      {!hideNav && <DesktopSidebar route={route} />}
      <div className="app-column">
        <TopBar title={title} back={back} />
        <main className="app-main">{children}</main>
        {!hideNav && <BottomNav route={route} />}
      </div>
    </div>
  );
}

function SectionTitle({
  eyebrow,
  title,
  action,
  onAction,
}: {
  eyebrow?: string;
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="section-title">
      <div>
        {eyebrow && <span>{eyebrow}</span>}
        <h2>{title}</h2>
      </div>
      {action && (
        <button onClick={onAction}>
          {action}
          <Icon name="chevron" size={15} />
        </button>
      )}
    </div>
  );
}

const courses = [
  {
    code: "CSC 301",
    title: "Data Structures & Algorithms",
    uni: "UNILAG",
    papers: 12,
    color: "purple",
    verified: true,
  },
  {
    code: "MTH 201",
    title: "Mathematical Methods I",
    uni: "UNILAG",
    papers: 8,
    color: "amber",
    verified: true,
  },
  {
    code: "CSC 307",
    title: "Operating Systems",
    uni: "UNILAG",
    papers: 6,
    color: "green",
    verified: false,
  },
  {
    code: "GST 103",
    title: "Nigerian Peoples & Culture",
    uni: "UNILAG",
    papers: 14,
    color: "blue",
    verified: true,
  },
];

function CourseCard({ course, onClick }: { course: (typeof courses)[0]; onClick?: () => void }) {
  return (
    <button className="course-card" onClick={onClick}>
      <span className={`course-icon tone-${course.color}`}>
        <Icon name="book" />
      </span>
      <span className="course-copy">
        <span className="course-tags">
          <Badge tone="purple">{course.uni}</Badge>
          {course.verified && (
            <Badge tone="green">
              <Icon name="check" size={11} />
              Verified
            </Badge>
          )}
        </span>
        <strong>{course.code}</strong>
        <small>{course.title}</small>
        <em>{course.papers} past papers</em>
      </span>
      <Icon name="chevron" />
    </button>
  );
}

function StatCard({
  icon,
  value,
  label,
  accent,
}: {
  icon: IconName;
  value: string;
  label: string;
  accent?: string;
}) {
  return (
    <div className={`stat-card ${accent || ""}`}>
      <span>
        <Icon name={icon} />
      </span>
      <b>{value}</b>
      <small>{label}</small>
    </div>
  );
}

function WelcomeScreen() {
  return (
    <div className="auth-shell">
      <div className="auth-art">
        <Logo />
        <div className="auth-orbit orbit-one" />
        <div className="auth-orbit orbit-two" />
        <div className="welcome-emblem">
          <span>
            <Icon name="spark" size={54} />
          </span>
          <i>R</i>
        </div>
        <div>
          <Badge tone="amber">Built for Nigerian students</Badge>
          <h1>
            Practice.
            <br />
            Battle. <em>Climb.</em>
          </h1>
          <p>Real past questions, smarter practice, and friendly competition—all in one place.</p>
        </div>
      </div>
      <div className="auth-panel">
        <h2>
          Your academic edge
          <br />
          starts here.
        </h2>
        <p>Join students across Nigerian universities turning practice into progress.</p>
        <Button full icon="arrow" onClick={() => go("signup")}>
          Create free account
        </Button>
        <Button full variant="secondary" onClick={() => go("login")}>
          I already have an account
        </Button>
        <small>By continuing, you agree to Rimbly’s Terms and Privacy Policy.</small>
      </div>
    </div>
  );
}

function AuthForm({ login = false }: { login?: boolean }) {
  const submit = (e: FormEvent) => {
    e.preventDefault();
    go(login ? "home" : "onboarding");
  };
  return (
    <div className="auth-form-page">
      <div className="auth-form-wrap">
        <div className="auth-form-head">
          <Logo />
          <button onClick={() => go("welcome")}>
            <Icon name="close" />
          </button>
        </div>
        <div className="auth-copy">
          <span className="eyebrow">{login ? "Welcome back" : "Join the climb"}</span>
          <h1>{login ? "Good to see you." : "Create your account."}</h1>
          <p>
            {login
              ? "Sign in to continue where you left off."
              : "Your next best score starts with one small step."}
          </p>
        </div>
        <button className="google-btn" onClick={() => go(login ? "home" : "onboarding")}>
          <b>G</b>Continue with Google
        </button>
        <div className="or">
          <span />
          or continue with email
          <span />
        </div>
        <form onSubmit={submit} className="form-stack">
          {!login && (
            <label>
              <span>Full name</span>
              <input required placeholder="e.g. Dami Adebayo" />
            </label>
          )}
          <label>
            <span>Email address</span>
            <input required type="email" placeholder="you@school.edu.ng" />
          </label>
          <label>
            <span>Password</span>
            <input required type="password" placeholder="At least 8 characters" />
          </label>
          {login && (
            <button className="forgot" type="button">
              Forgot password?
            </button>
          )}
          <Button type="submit" full icon="arrow">
            {login ? "Sign in" : "Create account"}
          </Button>
        </form>
        <p className="auth-switch">
          {login ? "New to Rimbly?" : "Already have an account?"}{" "}
          <button onClick={() => go(login ? "signup" : "login")}>
            {login ? "Create account" : "Sign in"}
          </button>
        </p>
      </div>
    </div>
  );
}

const onboardingSteps = [
  {
    eyebrow: "Step 1 of 5",
    title: "Where do you study?",
    help: "We’ll tailor past questions and rankings to your university.",
    label: "University",
    options: [
      "University of Lagos (UNILAG)",
      "University of Nigeria, Nsukka (UNN)",
      "University of Ibadan (UI)",
      "Obafemi Awolowo University (OAU)",
    ],
  },
  {
    eyebrow: "Step 2 of 5",
    title: "What’s your faculty?",
    help: "This helps us organise courses around your academic structure.",
    label: "Faculty",
    options: [
      "Faculty of Science",
      "Faculty of Engineering",
      "Faculty of Social Sciences",
      "Faculty of Arts",
    ],
  },
  {
    eyebrow: "Step 3 of 5",
    title: "Your programme?",
    help: "Course codes differ by university, so we keep your context precise.",
    label: "Department / Programme",
    options: ["Computer Science", "Computer Engineering", "Mathematics", "Systems Engineering"],
  },
  {
    eyebrow: "Step 4 of 5",
    title: "What level are you?",
    help: "Choose your current academic level.",
    label: "Current level",
    options: ["100 Level", "200 Level", "300 Level", "400 Level", "500 Level", "Postgraduate"],
  },
  {
    eyebrow: "Almost done",
    title: "Pick your courses.",
    help: "Optional—choose a few to personalise your home screen.",
    label: "Preferred courses",
    options: ["CSC 301", "CSC 305", "CSC 307", "MTH 201", "GST 103"],
  },
];
function Onboarding() {
  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const data = onboardingSteps[step];
  const next = () => {
    if (step < 4) {
      setStep(step + 1);
      setSelected([]);
    } else go("home");
  };
  return (
    <div className="onboarding-page">
      <header>
        <Logo />
        <button onClick={() => go("home")}>Skip for now</button>
      </header>
      <div className="onboarding-progress">
        <span style={{ width: `${(step + 1) * 20}%` }} />
      </div>
      <main>
        <span className="eyebrow">{data.eyebrow}</span>
        <h1>{data.title}</h1>
        <p>{data.help}</p>
        <label className="search-field">
          <Icon name="search" />
          <input placeholder={`Search ${data.label.toLowerCase()}`} />
        </label>
        <div className="option-list">
          {data.options.map((option) => (
            <button
              key={option}
              className={selected.includes(option) ? "selected" : ""}
              onClick={() =>
                setSelected(
                  step === 4
                    ? selected.includes(option)
                      ? selected.filter((x) => x !== option)
                      : [...selected, option]
                    : [option],
                )
              }
            >
              <span>{option}</span>
              <i>{selected.includes(option) && <Icon name="check" size={16} />}</i>
            </button>
          ))}
        </div>
      </main>
      <footer>
        <Button variant="ghost" onClick={() => (step ? setStep(step - 1) : go("signup"))}>
          Back
        </Button>
        <Button icon="arrow" onClick={next}>
          {step === 4 ? "Finish setup" : "Continue"}
        </Button>
      </footer>
    </div>
  );
}

function Home() {
  return (
    <AppShell route="home">
      <div className="dashboard-head">
        <div>
          <span className="eyebrow">Tuesday, 12 November</span>
          <h1>Good morning, Dami.</h1>
          <p>UNILAG · Computer Science · 300 Level</p>
        </div>
        <button className="desktop-bell" onClick={() => go("notifications")}>
          <Icon name="bell" />
          <i />
        </button>
      </div>
      <section className="resume-card">
        <div>
          <Badge tone="amber">
            <Icon name="clock" size={12} />
            Continue learning
          </Badge>
          <span>CSC 301 · UNILAG</span>
          <h2>Data Structures Quiz</h2>
          <p>Question 7 of 20 · 12 mins left</p>
          <Progress value={35} />
        </div>
        <button onClick={() => go("quiz")} aria-label="Resume quiz">
          <Icon name="play" />
        </button>
      </section>
      <section>
        <SectionTitle eyebrow="Jump back in" title="Quick actions" />
        <div className="quick-grid">
          <button onClick={() => go("practice")}>
            <span className="tone-purple">
              <Icon name="file" />
            </span>
            <b>Past Questions</b>
            <small>Browse verified papers</small>
          </button>
          <button onClick={() => go("quiz-setup")}>
            <span className="tone-amber">
              <Icon name="target" />
            </span>
            <b>Quiz Mode</b>
            <small>Test what you know</small>
          </button>
          <button onClick={() => go("battle")}>
            <span className="tone-green">
              <Icon name="swords" />
            </span>
            <b>Battle</b>
            <small>Challenge a student</small>
          </button>
          <button onClick={() => go("leaderboard")}>
            <span className="tone-blue">
              <Icon name="trophy" />
            </span>
            <b>Leaderboard</b>
            <small>See where you rank</small>
          </button>
        </div>
      </section>
      <section>
        <SectionTitle
          eyebrow="This semester"
          title="Your progress"
          action="View profile"
          onAction={() => go("profile")}
        />
        <div className="stats-grid">
          <StatCard icon="check" value="24" label="Quizzes done" />
          <StatCard icon="target" value="78%" label="Accuracy" />
          <StatCard icon="trophy" value="12–5" label="Battle record" />
          <StatCard icon="fire" value="8 days" label="Study streak" accent="hot" />
        </div>
      </section>
      <section>
        <SectionTitle title="Recently opened" action="See all" onAction={() => go("practice")} />
        <div className="horizontal-cards">
          {courses.slice(0, 3).map((c) => (
            <CourseCard key={c.code} course={c} onClick={() => go("course")} />
          ))}
        </div>
      </section>
      <section>
        <SectionTitle
          title="Recommended for you"
          action="See all"
          onAction={() => go("quiz-setup")}
        />
        <div className="recommend-grid">
          <article className="recommend-card purple">
            <Badge tone="purple">12 questions</Badge>
            <div>
              <span>CSC 301 · UNILAG</span>
              <h3>Sorting Algorithms Sprint</h3>
              <p>10 mins · Medium</p>
            </div>
            <Button variant="secondary" icon="arrow" onClick={() => go("quiz-setup")}>
              Start quiz
            </Button>
          </article>
          <article className="recommend-card amber">
            <Badge tone="amber">New paper</Badge>
            <div>
              <span>MTH 201 · UNILAG</span>
              <h3>2023/2024 First Semester</h3>
              <p>Exam · 14 pages</p>
            </div>
            <Button variant="secondary" icon="arrow" onClick={() => go("paper")}>
              Open paper
            </Button>
          </article>
        </div>
      </section>
    </AppShell>
  );
}

function Practice() {
  const [all, setAll] = useState(false);
  const [filter, setFilter] = useState(false);
  return (
    <AppShell route="practice" title="Practice">
      <div className="page-head">
        <span className="eyebrow">Past questions library</span>
        <h1>Practice with the real thing.</h1>
        <p>Original university papers, reviewed and organised for you.</p>
      </div>
      <div className="segment">
        <button className={!all ? "active" : ""} onClick={() => setAll(false)}>
          My University
        </button>
        <button className={all ? "active" : ""} onClick={() => setAll(true)}>
          All Universities
        </button>
      </div>
      <div className="search-row">
        <label className="search-field">
          <Icon name="search" />
          <input placeholder="Search course code or title" />
        </label>
        <button className="filter-btn" onClick={() => setFilter(true)}>
          <Icon name="filter" />
          <span>Filters</span>
          <i>2</i>
        </button>
      </div>
      <div className="filter-chips">
        <button className="selected">
          300 Level <Icon name="close" size={13} />
        </button>
        <button className="selected">
          1st Semester <Icon name="close" size={13} />
        </button>
        <button>
          Department <Icon name="chevron" size={12} />
        </button>
      </div>
      <section>
        <SectionTitle
          eyebrow={all ? "Across Nigeria" : "University of Lagos"}
          title="Your courses"
        />
        <div className="course-list">
          {courses.map((c) => (
            <CourseCard
              key={c.code}
              course={{ ...c, uni: all && c.code === "CSC 307" ? "UNN" : c.uni }}
              onClick={() => go("course")}
            />
          ))}
        </div>
      </section>
      <section>
        <SectionTitle title="Recently added" action="View all" />
        <div className="paper-scroll">
          {["2023/2024", "2022/2023", "2021/2022"].map((year, i) => (
            <button className="mini-paper" key={year} onClick={() => go("paper")}>
              <span>
                <Icon name="file" />
              </span>
              <Badge tone={i === 0 ? "amber" : "neutral"}>{i === 0 ? "New" : "Exam"}</Badge>
              <strong>{i === 1 ? "MTH 201" : "CSC 301"}</strong>
              <small>{year} · UNILAG</small>
            </button>
          ))}
        </div>
      </section>
      {filter && (
        <div className="sheet-backdrop" onClick={() => setFilter(false)}>
          <div className="bottom-sheet" onClick={(e) => e.stopPropagation()}>
            <header>
              <div>
                <span className="eyebrow">Refine library</span>
                <h2>Filters</h2>
              </div>
              <button onClick={() => setFilter(false)}>
                <Icon name="close" />
              </button>
            </header>
            {["Faculty", "Department", "Level", "Semester", "Session"].map((f, i) => (
              <label key={f}>
                <span>{f}</span>
                <select defaultValue={i === 2 ? "300 Level" : ""}>
                  <option value="">All {f.toLowerCase()}s</option>
                  <option>{i === 2 ? "300 Level" : "Computer Science"}</option>
                </select>
              </label>
            ))}
            <div className="sheet-actions">
              <Button variant="ghost">Reset</Button>
              <Button onClick={() => setFilter(false)}>Show 38 papers</Button>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function CourseDetail() {
  return (
    <AppShell route="practice" title="Course" back="practice">
      <section className="course-hero">
        <div className="course-hero-icon">
          <Icon name="book" size={28} />
        </div>
        <div>
          <div className="course-tags">
            <Badge tone="purple">UNILAG</Badge>
            <Badge tone="green">
              <Icon name="check" size={11} />
              Verified
            </Badge>
          </div>
          <h1>CSC 301</h1>
          <h2>Data Structures & Algorithms</h2>
          <p>Computer Science · 300 Level · First Semester</p>
        </div>
        <button className="icon-btn">
          <Icon name="bookmark" />
        </button>
      </section>
      <div className="course-actions">
        <Button full icon="target" onClick={() => go("quiz-setup")}>
          Start a quiz
        </Button>
        <Button full variant="secondary" icon="bookmark">
          Save course
        </Button>
      </div>
      <div className="context-note">
        <Icon name="shield" />
        <p>
          <b>University-specific course</b>
          <span>These papers are for CSC 301 at the University of Lagos.</span>
        </p>
      </div>
      <section>
        <SectionTitle eyebrow="12 original papers" title="Past papers" />
        <div className="year-group">
          <h3>2023 / 2024</h3>
          {["First Semester Examination", "Second Semester Test"].map((name, i) => (
            <button className="paper-row" key={name} onClick={() => go("paper")}>
              <span className="file-tile">
                <Icon name="file" />
              </span>
              <span>
                <b>{name}</b>
                <small>{i ? "Test · 8 pages" : "Exam · 14 pages"}</small>
              </span>
              <Badge tone={i ? "neutral" : "green"}>{i ? "Text ready" : "Verified"}</Badge>
              <Icon name="chevron" />
            </button>
          ))}
        </div>
        <div className="year-group">
          <h3>2022 / 2023</h3>
          <button className="paper-row" onClick={() => go("paper")}>
            <span className="file-tile">
              <Icon name="file" />
            </span>
            <span>
              <b>First Semester Examination</b>
              <small>Exam · 12 pages</small>
            </span>
            <Badge tone="green">Verified</Badge>
            <Icon name="chevron" />
          </button>
        </div>
      </section>
    </AppShell>
  );
}

function PaperDetail() {
  const [page, setPage] = useState(1);
  return (
    <AppShell route="practice" title="Past Paper" back="course">
      <div className="paper-meta-head">
        <div>
          <Badge tone="purple">UNILAG · CSC 301</Badge>
          <h1>2023/2024 First Semester Exam</h1>
          <p>Data Structures & Algorithms · 14 pages</p>
        </div>
        <button className="icon-btn">
          <Icon name="bookmark" />
        </button>
      </div>
      <div className="pdf-viewer">
        <div className="viewer-toolbar">
          <button onClick={() => setPage(Math.max(1, page - 1))}>
            <Icon name="back" />
          </button>
          <span>
            Page <b>{page}</b> of 14
          </span>
          <button onClick={() => setPage(Math.min(14, page + 1))}>
            <Icon name="arrow" />
          </button>
          <i />
          <button>
            <Icon name="download" />
          </button>
          <button>
            <Icon name="more" />
          </button>
        </div>
        <div className="paper-page">
          <div className="fake-crest">UL</div>
          <h3>UNIVERSITY OF LAGOS</h3>
          <p>FACULTY OF SCIENCE</p>
          <p>DEPARTMENT OF COMPUTER SCIENCE</p>
          <hr />
          <b>2023/2024 FIRST SEMESTER EXAMINATION</b>
          <div className="exam-info">
            <span>COURSE: CSC 301</span>
            <span>TIME: 2 HOURS</span>
          </div>
          <h4>Answer any FOUR questions</h4>
          <ol>
            <li>Define an abstract data type. Explain how it differs from a data structure.</li>
            <li>Using a suitable example, describe the operation of a binary search tree.</li>
            <li>Write an algorithm to perform merge sort on an array of integers.</li>
          </ol>
        </div>
      </div>
      <div className="paper-cta">
        <div>
          <Badge tone="green">
            <Icon name="check" size={11} />
            Structured questions ready
          </Badge>
          <h3>Ready to practise?</h3>
          <p>20 reviewed questions were derived from this original paper.</p>
        </div>
        <Button icon="target" onClick={() => go("quiz-setup")}>
          Start quiz
        </Button>
      </div>
      <section className="metadata-card">
        <h3>Document details</h3>
        <dl>
          <div>
            <dt>University</dt>
            <dd>University of Lagos</dd>
          </div>
          <div>
            <dt>Session</dt>
            <dd>2023/2024</dd>
          </div>
          <div>
            <dt>Contributor</dt>
            <dd>Oluwatobi A.</dd>
          </div>
          <div>
            <dt>Verification</dt>
            <dd>
              <Badge tone="green">Reviewed</Badge>
            </dd>
          </div>
        </dl>
        <button>Report incorrect content</button>
      </section>
    </AppShell>
  );
}

function QuizSetup() {
  const [count, setCount] = useState(20);
  const [timed, setTimed] = useState(true);
  return (
    <AppShell route="practice" title="Quiz Setup" back="course">
      <div className="page-head compact">
        <span className="eyebrow">Quiz mode</span>
        <h1>Build your practice.</h1>
        <p>Choose what to practise and make every question count.</p>
      </div>
      <div className="setup-card">
        <label>
          <span>University</span>
          <select defaultValue="unilag">
            <option value="unilag">University of Lagos (UNILAG)</option>
          </select>
        </label>
        <div className="form-two">
          <label>
            <span>Level</span>
            <select defaultValue="300">
              <option value="300">300 Level</option>
            </select>
          </label>
          <label>
            <span>Semester</span>
            <select defaultValue="first">
              <option value="first">First Semester</option>
            </select>
          </label>
        </div>
        <label>
          <span>Course</span>
          <select defaultValue="csc301">
            <option value="csc301">CSC 301 · Data Structures</option>
            <option>MTH 201 · Mathematical Methods</option>
          </select>
        </label>
        <fieldset>
          <legend>Number of questions</legend>
          <div className="choice-row">
            {[10, 20, 30].map((n) => (
              <button key={n} className={count === n ? "selected" : ""} onClick={() => setCount(n)}>
                {n}
                <small>questions</small>
              </button>
            ))}
          </div>
        </fieldset>
        <fieldset>
          <legend>Quiz timing</legend>
          <div className="timing-options">
            <button className={timed ? "selected" : ""} onClick={() => setTimed(true)}>
              <span>
                <Icon name="clock" />
              </span>
              <b>Timed</b>
              <small>20 minutes</small>
              <i>{timed && <Icon name="check" size={15} />}</i>
            </button>
            <button className={!timed ? "selected" : ""} onClick={() => setTimed(false)}>
              <span>
                <Icon name="book" />
              </span>
              <b>Untimed</b>
              <small>At your pace</small>
              <i>{!timed && <Icon name="check" size={15} />}</i>
            </button>
          </div>
        </fieldset>
        <div className="quiz-summary">
          <span>
            <b>{count}</b> questions
          </span>
          <span>
            <b>{timed ? `${count} min` : "∞"}</b> duration
          </span>
          <span>
            <b>+{count * 5}</b> max XP
          </span>
        </div>
        <Button full icon="arrow" onClick={() => go("quiz")}>
          Start quiz
        </Button>
      </div>
      <button className="history-link" onClick={() => go("quiz-history")}>
        <Icon name="clock" />
        View quiz history
      </button>
    </AppShell>
  );
}

const quizQuestions = [
  {
    q: "Which data structure follows the Last-In, First-Out (LIFO) principle?",
    options: ["Queue", "Stack", "Linked List", "Binary Tree"],
    answer: 1,
    explanation: "A stack follows LIFO: the last element added is the first one removed.",
  },
  {
    q: "What is the worst-case time complexity of binary search?",
    options: ["O(1)", "O(n)", "O(log n)", "O(n²)"],
    answer: 2,
    explanation:
      "Binary search halves the search space at each step, producing logarithmic complexity.",
  },
  {
    q: "Which traversal visits the root node before its subtrees?",
    options: ["In-order", "Post-order", "Level-order", "Pre-order"],
    answer: 3,
    explanation: "Pre-order traversal follows Root → Left → Right.",
  },
];
function ActiveQuiz({ battle = false }: { battle?: boolean }) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const q = quizQuestions[index];
  const next = () => {
    if (selected === null) return;
    const nextAnswers = [...answers, selected];
    setAnswers(nextAnswers);
    if (index === quizQuestions.length - 1) go(battle ? "battle-result" : "results");
    else {
      setIndex(index + 1);
      setSelected(null);
    }
  };
  return (
    <div className="focus-page">
      <header>
        <button onClick={() => go(battle ? "battle" : "quiz-setup")}>
          <Icon name="close" />
        </button>
        <div>
          <span>{battle ? "Battle · CSC 301" : "CSC 301 Quiz"}</span>
          <Progress value={((index + 1) / quizQuestions.length) * 100} />
        </div>
        <span className="timer">
          <Icon name="clock" size={16} />
          {battle ? "08:42" : "16:24"}
        </span>
      </header>
      {battle && (
        <div className="battle-scorebar">
          <div>
            <Avatar initials="DA" size="sm" />
            <span>
              You<b>{index * 10 + 20}</b>
            </span>
          </div>
          <strong>VS</strong>
          <div>
            <span>
              Tobi<b>{index * 10 + 10}</b>
            </span>
            <Avatar initials="TK" size="sm" />
          </div>
        </div>
      )}
      <main className="question-wrap">
        <div className="question-meta">
          <Badge tone="purple">
            Question {index + 1} of {quizQuestions.length}
          </Badge>
          <span>+5 XP</span>
        </div>
        <h1>{q.q}</h1>
        <div className="answer-list">
          {q.options.map((option, i) => (
            <button
              key={option}
              className={selected === i ? "selected" : ""}
              onClick={() => setSelected(i)}
            >
              <i>{String.fromCharCode(65 + i)}</i>
              <span>{option}</span>
              <em>{selected === i && <Icon name="check" size={16} />}</em>
            </button>
          ))}
        </div>
      </main>
      <footer>
        <button className="flag-btn">
          <Icon name="shield" size={17} />
          Flag question
        </button>
        <Button
          disabled={selected === null}
          icon={index === quizQuestions.length - 1 ? "check" : "arrow"}
          onClick={next}
        >
          {index === quizQuestions.length - 1 ? "Submit" : "Next question"}
        </Button>
      </footer>
    </div>
  );
}

function QuizResults() {
  const [tab, setTab] = useState<"summary" | "review">("summary");
  return (
    <AppShell route="practice" title="Quiz Results" back="course">
      <div className="result-hero">
        <span className="result-burst">
          <Icon name="spark" size={32} />
        </span>
        <Badge tone="green">Quiz complete</Badge>
        <h1>Strong work, Dami!</h1>
        <p>That’s a new personal best for CSC 301.</p>
        <div className="score-ring">
          <strong>85%</strong>
          <span>17 / 20</span>
        </div>
        <div className="xp-pill">+85 XP earned</div>
      </div>
      <div className="result-stats">
        <StatCard icon="check" value="17" label="Correct" />
        <StatCard icon="close" value="3" label="Incorrect" />
        <StatCard icon="clock" value="12:38" label="Time used" />
      </div>
      <div className="segment result-tabs">
        <button className={tab === "summary" ? "active" : ""} onClick={() => setTab("summary")}>
          Breakdown
        </button>
        <button className={tab === "review" ? "active" : ""} onClick={() => setTab("review")}>
          Review answers
        </button>
      </div>
      {tab === "summary" ? (
        <div className="breakdown-card">
          <h3>Topic performance</h3>
          {[
            ["Stacks & Queues", 100],
            ["Trees", 80],
            ["Sorting", 75],
            ["Complexity", 67],
          ].map(([name, value]) => (
            <Progress key={name as string} label={name as string} value={value as number} />
          ))}
        </div>
      ) : (
        <div className="review-list">
          {quizQuestions.map((q, i) => (
            <details key={q.q} open={i === 0}>
              <summary>
                <span className={i === 1 ? "wrong" : "right"}>
                  <Icon name={i === 1 ? "close" : "check"} />
                </span>
                <b>Question {i + 1}</b>
                <small>{i === 1 ? "Incorrect" : "Correct"}</small>
                <Icon name="chevron" />
              </summary>
              <div>
                <p>{q.q}</p>
                <span>
                  Your answer: <b>{q.options[i === 1 ? 0 : q.answer]}</b>
                </span>
                <span className="correct-answer">
                  Correct answer: <b>{q.options[q.answer]}</b>
                </span>
                <em>{q.explanation}</em>
              </div>
            </details>
          ))}
        </div>
      )}
      <div className="result-actions">
        <Button full icon="target" onClick={() => go("quiz-setup")}>
          Retry quiz
        </Button>
        <Button full variant="secondary" onClick={() => go("course")}>
          Back to course
        </Button>
        <button onClick={() => go("quiz-history")}>View quiz history</button>
      </div>
    </AppShell>
  );
}

function QuizHistory() {
  return (
    <AppShell route="practice" title="Quiz History" back="quiz-setup">
      <div className="page-head compact">
        <span className="eyebrow">Your practice record</span>
        <h1>Quiz history.</h1>
        <p>Track improvement and revisit the questions that challenged you.</p>
      </div>
      <div className="history-summary">
        <StatCard icon="target" value="78%" label="Avg. score" />
        <StatCard icon="check" value="24" label="Completed" />
        <StatCard icon="fire" value="8" label="Day streak" />
      </div>
      <div className="history-list">
        {[
          ["CSC 301", "Data Structures", 85, "Today · 12:38"],
          ["MTH 201", "Mathematical Methods", 70, "Yesterday · 18:05"],
          ["CSC 307", "Operating Systems", 90, "9 Nov · 09:24"],
          ["GST 103", "Nigerian Peoples", 65, "7 Nov · 15:42"],
        ].map(([code, title, score, date]) => (
          <button key={code as string} onClick={() => go("results")}>
            <span
              className={`score-box ${(score as number) >= 80 ? "great" : (score as number) >= 70 ? "good" : "fair"}`}
            >
              {score}%
            </span>
            <span>
              <b>{code} · UNILAG</b>
              <small>{title}</small>
              <em>{date}</em>
            </span>
            <Icon name="chevron" />
          </button>
        ))}
      </div>
    </AppShell>
  );
}

function BattleHome() {
  return (
    <AppShell route="battle" title="Battle">
      <div className="battle-hero">
        <Badge tone="amber" live>
          Battle arena
        </Badge>
        <h1>
          Ready to prove
          <br />
          what you know?
        </h1>
        <p>Same questions. Same time. May the sharpest mind win.</p>
        <div>
          <Button icon="search" onClick={() => go("challenge")}>
            Find an opponent
          </Button>
          <Button variant="secondary" icon="share" onClick={() => go("challenge")}>
            Challenge a friend
          </Button>
        </div>
        <span className="battle-art">
          <Icon name="swords" size={60} />
        </span>
      </div>
      <section>
        <SectionTitle eyebrow="Happening now" title="Active battles" />
        <button className="active-battle" onClick={() => go("battle-active")}>
          <div className="battle-players">
            <Avatar initials="DA" />
            <span>
              <b>42</b>
              <small>You</small>
            </span>
            <em>VS</em>
            <span>
              <b>38</b>
              <small>Tobi K.</small>
            </span>
            <Avatar initials="TK" />
          </div>
          <div>
            <Badge tone="amber" live>
              Live
            </Badge>
            <span>CSC 301 · 06:18 left</span>
            <Icon name="chevron" />
          </div>
        </button>
      </section>
      <section>
        <SectionTitle title="Pending challenges" />
        <div className="pending-card">
          <Avatar initials="AO" />
          <span>
            <b>Amara Okeke</b>
            <small>challenges you in MTH 201</small>
            <em>Expires in 18 mins</em>
          </span>
          <Button variant="secondary" onClick={() => go("battle-active")}>
            Accept
          </Button>
          <button>
            <Icon name="close" />
          </button>
        </div>
      </section>
      <section>
        <SectionTitle title="Recent battles" action="View history" />
        <div className="battle-history">
          {[
            ["TK", "Tobi K.", "CSC 301", "Won", "50 – 40"],
            ["IN", "Ife N.", "MTH 201", "Lost", "35 – 45"],
            ["AO", "Amara O.", "GST 103", "Won", "60 – 50"],
          ].map(([initial, name, course, result, score]) => (
            <div key={name}>
              <Avatar initials={initial} />
              <span>
                <b>{name}</b>
                <small>{course} · UNILAG</small>
              </span>
              <Badge tone={result === "Won" ? "green" : "red"}>{result}</Badge>
              <strong>{score}</strong>
            </div>
          ))}
        </div>
      </section>
    </AppShell>
  );
}

function Challenge() {
  const [mode, setMode] = useState<"match" | "friend">("match");
  const [searching, setSearching] = useState(false);
  return (
    <AppShell route="battle" title="New Battle" back="battle">
      <div className="page-head compact">
        <span className="eyebrow">Set the terms</span>
        <h1>Start a battle.</h1>
        <p>Choose your matchup and course. Questions are identical for both players.</p>
      </div>
      <div className="segment">
        <button className={mode === "match" ? "active" : ""} onClick={() => setMode("match")}>
          Find opponent
        </button>
        <button className={mode === "friend" ? "active" : ""} onClick={() => setMode("friend")}>
          Challenge friend
        </button>
      </div>
      <div className="setup-card challenge-card">
        {mode === "friend" && (
          <label>
            <span>Opponent</span>
            <div className="search-field">
              <Icon name="search" />
              <input placeholder="Search username or name" />
            </div>
          </label>
        )}
        <label>
          <span>University</span>
          <select>
            <option>University of Lagos (UNILAG)</option>
          </select>
        </label>
        <label>
          <span>Course</span>
          <select>
            <option>CSC 301 · Data Structures</option>
            <option>MTH 201 · Mathematical Methods</option>
          </select>
        </label>
        <div className="fair-play">
          <Icon name="shield" />
          <span>
            <b>Fair play enabled</b>
            <small>10 identical questions · 10 minutes · answers lock after selection</small>
          </span>
        </div>
        <Button
          full
          icon={searching ? "clock" : "swords"}
          onClick={() => {
            setSearching(true);
            setTimeout(() => go("battle-active"), 900);
          }}
        >
          {searching
            ? "Finding your match…"
            : mode === "friend"
              ? "Send challenge"
              : "Find my opponent"}
        </Button>
        {mode === "friend" && (
          <button className="invite-link">
            <Icon name="share" />
            Or copy an invite link
          </button>
        )}
      </div>
    </AppShell>
  );
}

function BattleResult() {
  return (
    <AppShell route="battle" title="Battle Result" back="battle">
      <div className="battle-result">
        <div className="winner-crown">
          <Icon name="trophy" size={36} />
        </div>
        <Badge tone="amber">Victory</Badge>
        <h1>You climbed!</h1>
        <p>Fast answers and a strong finish sealed it.</p>
        <div className="versus-result">
          <div className="winner">
            <Avatar initials="DA" size="lg" />
            <b>You</b>
            <strong>80</strong>
            <small>8 correct · 06:42</small>
          </div>
          <em>VS</em>
          <div>
            <Avatar initials="TK" size="lg" />
            <b>Tobi K.</b>
            <strong>60</strong>
            <small>6 correct · 07:10</small>
          </div>
        </div>
        <div className="rank-gain">
          <Icon name="chart" />
          <span>
            <b>+24 Battle Points</b>
            <small>You moved up 7 places to #42 at UNILAG</small>
          </span>
        </div>
      </div>
      <div className="result-actions">
        <Button full icon="swords" onClick={() => go("battle-active")}>
          Rematch
        </Button>
        <Button full variant="secondary" icon="share">
          Share result
        </Button>
        <button onClick={() => go("battle")}>Back to Battle home</button>
      </div>
    </AppShell>
  );
}

const leaders = [
  ["TK", "Tobi Kareem", "UNILAG", 2840],
  ["AO", "Amara Okeke", "UNN", 2720],
  ["IN", "Ife Nwosu", "OAU", 2655],
  ["MO", "Mide Olaniyi", "UI", 2510],
  ["ZA", "Zainab Ali", "ABU", 2450],
  ["DA", "Dami Adebayo", "UNILAG", 2320],
  ["CO", "Chidi Obi", "UNIPORT", 2285],
];
function Leaderboard() {
  const [tab, setTab] = useState("Overall");
  return (
    <AppShell route="leaderboard" title="Leaderboard">
      <div className="page-head">
        <span className="eyebrow">National rankings</span>
        <h1>Climb the board.</h1>
        <p>Earn points from quizzes, battles, and consistent practice.</p>
      </div>
      <div className="leader-tabs">
        {["Overall", "My University", "Quiz", "Battle"].map((t) => (
          <button className={tab === t ? "active" : ""} onClick={() => setTab(t)} key={t}>
            {t}
          </button>
        ))}
      </div>
      <div className="period-row">
        <span>Weekly ranking</span>
        <select>
          <option>This week</option>
          <option>All time</option>
        </select>
      </div>
      <div className="podium">
        {leaders.slice(0, 3).map((l, i) => (
          <div className={`place place-${i + 1}`} key={l[1] as string}>
            <Avatar initials={l[0] as string} size="lg" rank={i + 1} />
            <b>{l[1]}</b>
            <small>{l[2]}</small>
            <strong>{(l[3] as number).toLocaleString()} pts</strong>
          </div>
        ))}
      </div>
      <div className="ranking-list">
        {leaders.slice(3).map((l, i) => (
          <div className={l[1] === "Dami Adebayo" ? "me" : ""} key={l[1] as string}>
            <b>{i + 4}</b>
            <Avatar initials={l[0] as string} />
            <span>
              <strong>
                {l[1]}
                {l[1] === "Dami Adebayo" && <em>You</em>}
              </strong>
              <small>{l[2]} · 300L</small>
            </span>
            <strong>{(l[3] as number).toLocaleString()}</strong>
          </div>
        ))}
      </div>
      <div className="scoring-note">
        <Icon name="spark" />
        <span>
          <b>How points work</b>
          <p>Quiz accuracy, battle wins, and streaks earn points. Rankings reset every Monday.</p>
        </span>
        <button>Learn more</button>
      </div>
    </AppShell>
  );
}

function Profile() {
  return (
    <AppShell route="profile" title="Profile">
      <section className="profile-head">
        <button className="profile-settings">
          <Icon name="settings" />
        </button>
        <Avatar initials="DA" size="lg" />
        <div>
          <h1>Dami Adebayo</h1>
          <p>@dami.codes</p>
          <div>
            <Badge tone="purple">UNILAG</Badge>
            <Badge tone="neutral">Computer Science · 300L</Badge>
          </div>
        </div>
        <Button variant="secondary">Edit profile</Button>
      </section>
      <div className="profile-stats">
        <StatCard icon="check" value="24" label="Quizzes" />
        <StatCard icon="target" value="78%" label="Accuracy" />
        <StatCard icon="trophy" value="12" label="Wins" />
        <StatCard icon="fire" value="8" label="Day streak" />
      </div>
      <section>
        <SectionTitle eyebrow="Keep climbing" title="Achievements" action="View all" />
        <div className="badge-row">
          {[
            ["spark", "First Steps", "Complete 1 quiz"],
            ["fire", "On Fire", "7 day streak"],
            ["trophy", "Contender", "Win 10 battles"],
            ["target", "Sharp Mind", "90% quiz score"],
          ].map(([icon, name, desc], i) => (
            <div className={i === 3 ? "locked" : ""} key={name}>
              <span>
                <Icon name={icon as IconName} />
              </span>
              <b>{name}</b>
              <small>{desc}</small>
            </div>
          ))}
        </div>
      </section>
      <section>
        <SectionTitle title="Saved for later" action="View all" />
        <div className="course-list compact-list">
          {courses.slice(0, 2).map((c) => (
            <CourseCard key={c.code} course={c} onClick={() => go("course")} />
          ))}
        </div>
      </section>
      <section>
        <SectionTitle title="Recent activity" />
        <div className="activity-feed">
          {[
            ["target", "Scored 85% in CSC 301", "Today, 10:32"],
            ["trophy", "Won a battle against Tobi K.", "Yesterday, 19:14"],
            ["upload", "Your MTH 201 paper was approved", "8 Nov, 12:05"],
          ].map(([icon, text, date]) => (
            <div key={text}>
              <span>
                <Icon name={icon as IconName} />
              </span>
              <p>
                <b>{text}</b>
                <small>{date}</small>
              </p>
            </div>
          ))}
        </div>
      </section>
      <div className="profile-menu">
        <button onClick={() => go("contribute")}>
          <Icon name="upload" />
          <span>
            My contributions<small>2 approved · 1 pending</small>
          </span>
          <Icon name="chevron" />
        </button>
        <button onClick={() => go("suggest")}>
          <Icon name="spark" />
          <span>
            Suggestions & reports<small>Help improve Rimbly</small>
          </span>
          <Icon name="chevron" />
        </button>
        <button>
          <Icon name="settings" />
          <span>
            Settings<small>Account, privacy, preferences</small>
          </span>
          <Icon name="chevron" />
        </button>
        <button className="logout" onClick={() => go("welcome")}>
          <Icon name="logout" />
          <span>Log out</span>
        </button>
      </div>
    </AppShell>
  );
}

function Contribution({ suggest = false }: { suggest?: boolean }) {
  const [sent, setSent] = useState(false);
  const [tab, setTab] = useState("New");
  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };
  return (
    <AppShell route="profile" title={suggest ? "Suggestions" : "Contribute"} back="profile">
      <div className="page-head compact">
        <span className="eyebrow">{suggest ? "Help shape Rimbly" : "Grow the archive"}</span>
        <h1>{suggest ? "Spot something we should fix?" : "Your papers. Everyone’s edge."}</h1>
        <p>
          {suggest
            ? "Suggest missing academic structure or report content that needs attention."
            : "Contribute a clear scan or photo. Every submission is reviewed before publishing."}
        </p>
      </div>
      {!suggest && (
        <div className="segment">
          <button className={tab === "New" ? "active" : ""} onClick={() => setTab("New")}>
            New contribution
          </button>
          <button className={tab === "Mine" ? "active" : ""} onClick={() => setTab("Mine")}>
            My contributions
          </button>
        </div>
      )}
      {tab === "Mine" && !suggest ? (
        <div className="contribution-list">
          {[
            ["CSC 307 · 2022 Exam", "Approved", "Published 6 Nov"],
            ["MTH 201 · 2023 Test", "Pending", "Submitted 10 Nov"],
            ["GST 103 · 2021 Exam", "Rejected", "Duplicate document"],
          ].map(([name, status, note]) => (
            <div key={name}>
              <span className="file-tile">
                <Icon name="file" />
              </span>
              <span>
                <b>{name}</b>
                <small>UNILAG · {note}</small>
              </span>
              <Badge
                tone={status === "Approved" ? "green" : status === "Pending" ? "amber" : "red"}
              >
                {status}
              </Badge>
            </div>
          ))}
        </div>
      ) : sent ? (
        <div className="form-success">
          <span>
            <Icon name="check" size={34} />
          </span>
          <Badge tone="green">Received</Badge>
          <h2>{suggest ? "Thanks for speaking up." : "Contribution submitted."}</h2>
          <p>
            {suggest
              ? "We’ll review your note and follow up if we need more detail."
              : "Our academic review team will verify the document. You can track its status from your profile."}
          </p>
          <Button onClick={() => setSent(false)}>
            {suggest ? "Send another" : "Contribute another"}
          </Button>
          <Button variant="ghost" onClick={() => go("profile")}>
            Back to profile
          </Button>
        </div>
      ) : (
        <form className="contribution-form" onSubmit={submit}>
          {suggest ? (
            <>
              <label>
                <span>What is this about?</span>
                <select>
                  <option>Missing university</option>
                  <option>Missing course or department</option>
                  <option>Incorrect content</option>
                  <option>Product suggestion</option>
                </select>
              </label>
              <label>
                <span>University / course context</span>
                <input placeholder="e.g. UNILAG · CSC 301" />
              </label>
              <label>
                <span>Tell us what needs attention</span>
                <textarea required placeholder="Be specific so our team can act quickly…" />
              </label>
            </>
          ) : (
            <>
              <label>
                <span>University</span>
                <select>
                  <option>University of Lagos (UNILAG)</option>
                </select>
              </label>
              <div className="form-two">
                <label>
                  <span>Course code</span>
                  <input required placeholder="e.g. CSC 301" />
                </label>
                <label>
                  <span>Session</span>
                  <input required placeholder="e.g. 2023/2024" />
                </label>
              </div>
              <label>
                <span>Course title</span>
                <input required placeholder="e.g. Data Structures" />
              </label>
              <label className="upload-area">
                <input type="file" />
                <span>
                  <Icon name="upload" />
                </span>
                <b>Upload PDF or images</b>
                <small>PDF, JPG or PNG · Up to 20MB</small>
              </label>
              <label>
                <span>
                  Helpful context <small>Optional</small>
                </span>
                <textarea placeholder="Semester, exam type, lecturer or anything useful…" />
              </label>
            </>
          )}
          <Button type="submit" full icon="arrow">
            {suggest ? "Send suggestion" : "Submit for review"}
          </Button>
        </form>
      )}
    </AppShell>
  );
}

function Notifications() {
  const [read, setRead] = useState(false);
  return (
    <AppShell route="home" title="Notifications" back="home">
      <div className="notification-head">
        <div>
          <span className="eyebrow">Stay in the loop</span>
          <h1>Notifications.</h1>
        </div>
        <button onClick={() => setRead(true)}>Mark all as read</button>
      </div>
      <div className="notification-list">
        {[
          ["swords", "Battle invite", "Amara challenged you in MTH 201.", "2 mins ago", "purple"],
          ["trophy", "You won!", "Your battle with Tobi ended 80–60.", "1 hour ago", "amber"],
          [
            "check",
            "Contribution approved",
            "CSC 307 · 2022 Exam is now live.",
            "Yesterday",
            "green",
          ],
          ["spark", "New achievement", "You earned the On Fire badge.", "2 days ago", "purple"],
          [
            "bell",
            "New papers for you",
            "3 UNILAG Computer Science papers were added.",
            "3 days ago",
            "neutral",
          ],
        ].map(([icon, title, text, time, tone], i) => (
          <button
            className={!read && i < 2 ? "unread" : ""}
            key={title}
            onClick={() => i === 0 && go("challenge")}
          >
            <span className={`notice-icon tone-${tone}`}>
              <Icon name={icon as IconName} />
            </span>
            <span>
              <b>{title}</b>
              <p>{text}</p>
              <small>{time}</small>
            </span>
            {!read && i < 2 && <i />}
          </button>
        ))}
      </div>
      <EmptyCard
        icon="bell"
        title="All caught up"
        text="New battle invites, results, and updates will appear here."
      />
    </AppShell>
  );
}

function EmptyCard({
  icon,
  title,
  text,
  action,
}: {
  icon: IconName;
  title: string;
  text: string;
  action?: string;
}) {
  return (
    <div className="empty-card">
      <span>
        <Icon name={icon} size={28} />
      </span>
      <h3>{title}</h3>
      <p>{text}</p>
      {action && <Button variant="secondary">{action}</Button>}
    </div>
  );
}
function StatesPage() {
  return (
    <AppShell route="profile" title="States" back="components">
      <div className="page-head compact">
        <span className="eyebrow">System feedback</span>
        <h1>Empty & error states.</h1>
      </div>
      <div className="states-grid">
        <EmptyCard
          icon="file"
          title="No papers here yet"
          text="Be the first to contribute a paper for CSC 405 at UNILAG."
          action="Contribute a paper"
        />
        <EmptyCard
          icon="swords"
          title="No battles yet"
          text="Your battle history will appear here after your first matchup."
          action="Find an opponent"
        />
        <EmptyCard
          icon="bell"
          title="Quiet for now"
          text="Battle invites and academic updates will show up here."
        />
        <div className="empty-card error">
          <span>
            <Icon name="close" size={28} />
          </span>
          <h3>Couldn’t connect</h3>
          <p>Check your internet connection and try again.</p>
          <Button variant="secondary">Retry</Button>
        </div>
        <div className="empty-card pending">
          <span>
            <Icon name="clock" size={28} />
          </span>
          <Badge tone="amber">Under review</Badge>
          <h3>Contribution pending</h3>
          <p>Our team is checking your document for quality and academic context.</p>
        </div>
      </div>
    </AppShell>
  );
}

function ComponentsPage() {
  return (
    <AppShell route="profile" title="UI Library" back="profile">
      <div className="page-head">
        <span className="eyebrow">Rimbly design system</span>
        <h1>Soft, bold, unmistakably Rimbly.</h1>
        <p>A practical component library built for focused learning on small screens.</p>
      </div>
      <section className="component-section">
        <SectionTitle title="Core palette" />
        <div className="swatches">
          {[
            ["Ink", "#0F0F0F"],
            ["Primary", "#6D28D9"],
            ["Accent", "#F59E0B"],
            ["Success", "#16A34A"],
            ["Canvas", "#F7F5F2"],
            ["Surface", "#FFFFFF"],
          ].map(([n, h]) => (
            <div key={n} style={{ "--swatch": h } as React.CSSProperties}>
              <i />
              <b>{n}</b>
              <small>{h}</small>
            </div>
          ))}
        </div>
      </section>
      <section className="component-section">
        <SectionTitle title="Buttons" />
        <div className="component-row">
          <Button>Primary action</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="amber">Highlight</Button>
          <Button variant="danger">Destructive</Button>
          <Button variant="ghost">Ghost</Button>
        </div>
      </section>
      <section className="component-section">
        <SectionTitle title="Inputs & selects" />
        <div className="component-form">
          <label>
            <span>Course code</span>
            <input placeholder="e.g. CSC 301" />
          </label>
          <label>
            <span>Level</span>
            <select>
              <option>300 Level</option>
            </select>
          </label>
          <label>
            <span>Notes</span>
            <textarea placeholder="Add context…" />
          </label>
        </div>
      </section>
      <section className="component-section">
        <SectionTitle title="Chips & badges" />
        <div className="component-row">
          <Badge tone="purple">UNILAG</Badge>
          <Badge tone="green">
            <Icon name="check" size={11} />
            Verified
          </Badge>
          <Badge tone="amber" live>
            Live
          </Badge>
          <Badge tone="red">Rejected</Badge>
          <button className="chip-demo">
            300 Level <Icon name="close" size={12} />
          </button>
        </div>
      </section>
      <section className="component-section">
        <SectionTitle title="Cards" />
        <div className="component-cards">
          <CourseCard course={courses[0]} />
          <StatCard icon="target" value="78%" label="Average accuracy" />
          <div className="toast">
            <span>
              <Icon name="check" />
            </span>
            <p>
              <b>Saved for later</b>
              <small>CSC 301 added to your library.</small>
            </p>
            <button>
              <Icon name="close" />
            </button>
          </div>
        </div>
      </section>
      <Button variant="secondary" onClick={() => go("states")}>
        View empty & error states
      </Button>
    </AppShell>
  );
}

function Admin() {
  const [section, setSection] = useState("Moderation");
  const adminNav = [
    "Overview",
    "Academic Management",
    "Past Questions",
    "Quiz Management",
    "Battle",
    "Users",
    "Team",
    "Analytics",
    "Audit Logs",
    "Settings",
  ];
  return (
    <div className="admin-shell">
      <aside>
        <Logo />
        <Badge tone="amber">Admin</Badge>
        <nav>
          {adminNav.map((n, i) => (
            <button
              className={
                section === n || (section === "Moderation" && n === "Past Questions")
                  ? "active"
                  : ""
              }
              onClick={() => setSection(n)}
              key={n}
            >
              <Icon
                name={
                  (i === 0
                    ? "grid"
                    : i === 1
                      ? "book"
                      : i === 2
                        ? "file"
                        : i === 3
                          ? "target"
                          : i === 4
                            ? "swords"
                            : i === 5
                              ? "users"
                              : i === 7
                                ? "chart"
                                : "settings") as IconName
                }
              />
              {n}
            </button>
          ))}
        </nav>
        <div className="admin-user">
          <Avatar initials="KA" />
          <span>
            <b>Kemi A.</b>
            <small>Content Admin</small>
          </span>
        </div>
      </aside>
      <main>
        <header>
          <div>
            <span className="eyebrow">Admin workspace</span>
            <h1>
              {section === "Past Questions" || section === "Moderation"
                ? "Content moderation"
                : section}
            </h1>
          </div>
          <div>
            <label className="search-field">
              <Icon name="search" />
              <input placeholder="Search records" />
            </label>
            <button className="icon-btn">
              <Icon name="bell" />
            </button>
          </div>
        </header>
        <div className="admin-stats">
          <StatCard icon="clock" value="42" label="Pending review" />
          <StatCard icon="check" value="186" label="Approved this week" />
          <StatCard icon="file" value="1,284" label="Total documents" />
          <StatCard icon="shield" value="8" label="Flagged items" />
        </div>
        <div className="admin-grid">
          <section className="admin-table-card">
            <div className="admin-card-head">
              <div>
                <span className="eyebrow">Priority queue</span>
                <h2>Documents awaiting review</h2>
              </div>
              <Button variant="secondary" icon="filter">
                Filter
              </Button>
            </div>
            <table>
              <thead>
                <tr>
                  <th>Document</th>
                  <th>Academic context</th>
                  <th>Submitted</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {[
                  ["CSC 301 · 2023/24 Exam", "UNILAG · Science · 300L", "12 mins ago"],
                  ["MTH 201 · 2022/23 Test", "UNN · Physical Sciences · 200L", "34 mins ago"],
                  ["LAW 403 · 2023/24 Exam", "OAU · Law · 400L", "1 hour ago"],
                  ["EEE 307 · 2021/22 Exam", "FUTA · Engineering · 300L", "2 hours ago"],
                ].map((r, i) => (
                  <tr key={r[0]}>
                    <td>
                      <span className="file-tile">
                        <Icon name="file" />
                      </span>
                      <b>{r[0]}</b>
                    </td>
                    <td>{r[1]}</td>
                    <td>{r[2]}</td>
                    <td>
                      <Badge tone={i === 2 ? "red" : "amber"}>
                        {i === 2 ? "Flagged" : "Pending"}
                      </Badge>
                    </td>
                    <td>
                      <Button variant="secondary">Review</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
          <aside className="structure-card">
            <div className="admin-card-head">
              <div>
                <span className="eyebrow">Academic structure</span>
                <h2>Coverage health</h2>
              </div>
            </div>
            <div className="coverage-ring">
              <strong>68%</strong>
              <span>Structured</span>
            </div>
            {[
              ["Universities", "94 of 170"],
              ["Faculties", "418 mapped"],
              ["Departments", "1,204 mapped"],
              ["Courses", "8,421 active"],
            ].map(([n, v]) => (
              <div className="coverage-row" key={n}>
                <span>{n}</span>
                <b>{v}</b>
              </div>
            ))}
            <Button full variant="secondary" onClick={() => setSection("Academic Management")}>
              Manage structure
            </Button>
          </aside>
        </div>
      </main>
    </div>
  );
}

export default function App() {
  const [route, setRoute] = useState<Route>(routeFromHash);
  useEffect(() => {
    const change = () => {
      setRoute(routeFromHash());
      window.scrollTo({ top: 0, behavior: "smooth" });
    };
    window.addEventListener("hashchange", change);
    return () => window.removeEventListener("hashchange", change);
  }, []);
  const screen = useMemo(() => {
    switch (route) {
      case "welcome":
        return <WelcomeScreen />;
      case "signup":
        return <AuthForm />;
      case "login":
        return <AuthForm login />;
      case "onboarding":
        return <Onboarding />;
      case "home":
        return <Home />;
      case "practice":
        return <Practice />;
      case "course":
        return <CourseDetail />;
      case "paper":
        return <PaperDetail />;
      case "quiz-setup":
        return <QuizSetup />;
      case "quiz":
        return <ActiveQuiz />;
      case "results":
        return <QuizResults />;
      case "quiz-history":
        return <QuizHistory />;
      case "battle":
        return <BattleHome />;
      case "challenge":
        return <Challenge />;
      case "battle-active":
        return <ActiveQuiz battle />;
      case "battle-result":
        return <BattleResult />;
      case "leaderboard":
        return <Leaderboard />;
      case "profile":
        return <Profile />;
      case "contribute":
        return <Contribution />;
      case "suggest":
        return <Contribution suggest />;
      case "notifications":
        return <Notifications />;
      case "states":
        return <StatesPage />;
      case "components":
        return <ComponentsPage />;
      case "admin":
        return <Admin />;
      default:
        return <Home />;
    }
  }, [route]);
  return screen;
}
